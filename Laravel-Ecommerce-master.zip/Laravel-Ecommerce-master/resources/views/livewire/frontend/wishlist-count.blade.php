<div class="d-inline">
    {{ $wishlistCount }}
</div>
