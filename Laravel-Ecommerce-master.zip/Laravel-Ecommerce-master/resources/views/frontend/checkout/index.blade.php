@extends('layouts.app')

@section('title', 'Checkout')

@section('content')

    <div>
        <livewire:frontend.checkout.checkout-show />
    </div>

@endsection
