@extends('layouts.app')

@section('title', 'Wishlist')

@section('content')

    <div>
       <livewire:frontend.wishlist-show />
    </div>

@endsection
