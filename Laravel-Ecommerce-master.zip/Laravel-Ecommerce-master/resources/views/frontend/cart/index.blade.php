@extends('layouts.app')

@section('title', 'Cart')

@section('content')

    <div>
       <livewire:frontend.cart.cart-show />
    </div>

@endsection
