@extends('layouts.admin')

@section('title', 'Categories')

@section('content')

<div>
    <livewire:admin.category.index />
</div>

@endsection
